# Lambda - no celery
